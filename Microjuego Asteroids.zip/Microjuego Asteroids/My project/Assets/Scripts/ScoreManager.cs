using UnityEngine;
using TMPro;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    [Header("Referencias UI (Arrastrar desde la Hierarchy)")]
    public TextMeshProUGUI scoreText;          // Arrastra aquí tu texto de puntuación
    public TextMeshProUGUI highScoreText;      // Opcional (déjalo vacío si no lo usas)
    public TextMeshProUGUI oneUpLabel;         // Opcional (déjalo vacío si no lo usas)

    [Header("Efecto de Salto (Solo Escala)")]
    public float punchScale = 1.3f;            // Cuánto se infla al puntuar
    public float returnSpeed = 8f;             // Rapidez con la que vuelve a su tamaño normal
    public float countSpeed = 8f;              // Velocidad a la que ruedan los números

    private int _targetScore = 0;
    private float _displayedScore = 0f;
    private int _highScore = 0;
    private Vector3 _originalScale;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    void Start()
    {
        if (scoreText != null)
        {
            _originalScale = scoreText.transform.localScale;
            scoreText.text = "000000";
        }

        // Cargar récord guardado (inicia en 5000 por defecto)
        _highScore = PlayerPrefs.GetInt("HighScore", 5000);
        if (highScoreText != null)
        {
            highScoreText.text = _highScore.ToString("D6");
        }
    }

    void Update()
    {
        // 1. Números rodando hacia la puntuación real
        if (_displayedScore < _targetScore)
        {
            _displayedScore = Mathf.MoveTowards(
                _displayedScore,
                _targetScore,
                (_targetScore - _displayedScore + 20f) * Time.deltaTime * countSpeed
            );

            if (scoreText != null)
            {
                scoreText.text = Mathf.RoundToInt(_displayedScore).ToString("D6");
            }
        }

        // 2. Vuelta suave a la escala original (sin tocar colores)
        if (scoreText != null)
        {
            scoreText.transform.localScale = Vector3.Lerp(
                scoreText.transform.localScale,
                _originalScale,
                Time.deltaTime * returnSpeed
            );
        }

        // 3. Parpadeo clásico del letrero "1UP" (si existe)
        if (oneUpLabel != null)
        {
            oneUpLabel.enabled = (Mathf.FloorToInt(Time.time * 2f) % 2 == 0);
        }
    }

    public void AddScore(int points)
    {
        _targetScore += points;

        // Salto de escala al impactar
        if (scoreText != null)
        {
            scoreText.transform.localScale = _originalScale * punchScale;
        }

        // Actualizar High Score si lo superas
        if (_targetScore > _highScore)
        {
            _highScore = _targetScore;
            PlayerPrefs.SetInt("HighScore", _highScore);
            if (highScoreText != null)
            {
                highScoreText.text = _highScore.ToString("D6");
            }
        }
    }
    public int GetCurrentScore()
    {
        return _targetScore;
    }
}