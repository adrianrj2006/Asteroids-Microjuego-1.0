using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 10f;
    public float maxLifeTime = 3f;
    public Vector3 targetVector;

    [Header("Daño y Perforación")]
    public int damage = 1;                  // 1 de daño por defecto (tiro normal)
    public bool isPiercing = false;
    public int maxHits = 1;
    private int _currentHits = 0;

    void Start()
    {
        Destroy(gameObject, maxLifeTime);
    }

    void Update()
    {
        transform.Translate(speed * targetVector * Time.deltaTime, Space.World);
    }

    // Configuración cuando sale cargada
    public void SetupChargedShot(float scaleMultiplier, float speedMultiplier, int hitsCapacity)
    {
        transform.localScale *= scaleMultiplier;
        speed *= speedMultiplier;
        isPiercing = true;
        maxHits = hitsCapacity;
        damage = 2; // El tiro cargado hace 2 de daño (destruye de un golpe)
    }

    public void RegisterHit()
    {
        _currentHits++;
        if (!isPiercing || _currentHits >= maxHits)
        {
            Destroy(gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            // Buscamos el componente Meteor en el objeto que golpeamos
            Meteor meteor = collision.gameObject.GetComponent<Meteor>();
            if (meteor != null)
            {
                meteor.TakeDamage(damage);
            }

            RegisterHit(); // La bala se destruye salvo si es perforante y le quedan impactos
        }
    }
}