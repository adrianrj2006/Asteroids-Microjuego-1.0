using System.Collections;
using UnityEngine;

public class Meteor : MonoBehaviour
{
    [Header("Vida")]
    public int maxHealth = 2;
    private int _currentHealth;

    [Header("Feedback de Daño (Estilo Cuphead)")]
    public Color hitFlashColor = Color.white;
    public float flashDuration = 0.07f;

    [Header("Puntuación")]
    public int scoreValue = 100;

    private SpriteRenderer _rockRenderer;
    private Color _originalColor;
    private Vector3 _baseScale;
    private bool _isDying = false;

    void Start()
    {
        _currentHealth = maxHealth;
        _rockRenderer = GetComponent<SpriteRenderer>();
        if (_rockRenderer != null)
        {
            _originalColor = _rockRenderer.color;
        }
        _baseScale = transform.localScale;
    }

    public void TakeDamage(int damage)
    {
        if (_isDying) return;

        _currentHealth -= damage;

        if (_currentHealth <= 0)
        {
            StartCoroutine(DieEffect());
        }
        else
        {
            StopAllCoroutines();
            StartCoroutine(HitFeedback());
        }
    }

    private IEnumerator HitFeedback()
    {
        if (_rockRenderer != null) _rockRenderer.color = hitFlashColor;

        transform.localScale = new Vector3(_baseScale.x * 1.1f, _baseScale.y * 0.9f, _baseScale.z);

        yield return new WaitForSeconds(flashDuration);

        if (_rockRenderer != null) _rockRenderer.color = _originalColor;
        transform.localScale = _baseScale;
    }

    private IEnumerator DieEffect()
    {
        _isDying = true;

        if (ScoreManager.Instance != null)
        {
            ScoreManager.Instance.AddScore(scoreValue);
        }

        Collider col = GetComponent<Collider>();
        if (col != null) col.enabled = false;

        if (_rockRenderer != null) _rockRenderer.color = Color.white;
        transform.localScale = _baseScale * 1.25f;

        yield return new WaitForSeconds(0.06f);

        Destroy(gameObject);
    }
}