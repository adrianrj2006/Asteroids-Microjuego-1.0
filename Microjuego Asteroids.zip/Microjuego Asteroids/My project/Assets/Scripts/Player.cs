using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float thrustForce = 5f;
    public float rotationSpeed = 120f;

    public GameObject ShipFire;
    private Vector3 _escalaOriginalFuego;
    private Rigidbody _rigid;

    [Header("Límites de Pantalla")]
    public float xLimit = 8f;
    public float yLimit = 6f;

    void Start()
    {
        _rigid = GetComponent<Rigidbody>();
        if (ShipFire != null)
        {
            _escalaOriginalFuego = ShipFire.transform.localScale;
            ShipFire.SetActive(false);
        }
    }

    void Update()
    {
        float thrust = Input.GetAxis("Vertical") * Time.deltaTime;
        float rotation = Input.GetAxis("Horizontal") * Time.deltaTime;

        Vector3 thrustDirection = transform.right;

        _rigid.AddForce(thrustDirection * thrust * thrustForce);
        transform.Rotate(Vector3.forward, -rotation * rotationSpeed);

        if (ShipFire != null)
        {
            if (thrust > 0)
            {
                ShipFire.SetActive(true);

                float factorVibracion = Random.Range(0.8f, 1.25f);
                ShipFire.transform.localScale = new Vector3(
                    _escalaOriginalFuego.x * factorVibracion,
                    _escalaOriginalFuego.y,
                    _escalaOriginalFuego.z
                );
            }
            else
            {
                ShipFire.SetActive(false);
            }
        }
        HandleScreenWrap();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            // Guarda la puntuación de esta partida
            if (ScoreManager.Instance != null)
            {
                PlayerPrefs.SetInt("LastScore", ScoreManager.Instance.GetCurrentScore());
            }

            // Asegura que el tiempo no esté congelado y viaja al Menú
            Time.timeScale = 1f;
            SceneManager.LoadScene("MenuScene");
        }
        else
        {
            Debug.Log("Colision con otra cosa");
        }
    }

    void HandleScreenWrap()
    {
        Vector3 pos = transform.position;

        // Teletransporte en el eje X
        if (pos.x > xLimit)
        {
            pos.x = -xLimit;
        }
        else if (pos.x < -xLimit)
        {
            pos.x = xLimit;
        }

        // Teletransporte en el eje Y
        if (pos.y > yLimit)
        {
            pos.y = -yLimit;
        }
        else if (pos.y < -yLimit)
        {
            pos.y = yLimit;
        }

        transform.position = pos;

        // Mantiene la física sincronizada al instante
        if (_rigid != null)
        {
            _rigid.position = pos;
        }
    }
}