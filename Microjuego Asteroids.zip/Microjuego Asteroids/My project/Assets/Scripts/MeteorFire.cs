using UnityEngine;

public class MeteorFire : MonoBehaviour
{
    [Header("Turbulencia de la Llama")]
    public float flameSpeed = 14f;            // Rapidez del aleteo de las puntas
    public float stretchAmount = 0.08f;       // Cuánto se estiran las puntas
    public float widthWobble = 0.03f;         // Micro-variación en el ancho

    [Header("Temperatura y Color (Suavizado)")]
    public Color normalColor = Color.white;                   // Color natural del sprite
    public Color warmGlowColor = new Color(1f, 0.82f, 0.65f); // Tinte cálido suave (sin oscurecerlo)
    public float colorPulseSpeed = 4.5f;                      // Respiración pausada (antes era 12f)
    [Range(0f, 1f)]
    public float colorBlendIntensity = 0.45f;                 // Intensidad máxima del tinte

    private Vector3 _originalScale;
    private SpriteRenderer _sr;
    private float _seed;

    void Start()
    {
        _originalScale = transform.localScale;
        _sr = GetComponent<SpriteRenderer>();
        _seed = Random.Range(0f, 1000f);
    }

    void Update()
    {
        float time = Time.time * flameSpeed;

        // 1. Movimiento fluido de las puntas (Perlin Noise)
        float noiseY = Mathf.PerlinNoise(time, _seed);
        float noiseX = Mathf.PerlinNoise(_seed, time);

        float factorY = 1f + (noiseY * stretchAmount);
        float factorX = 1f + ((noiseX - 0.5f) * 2f * widthWobble);

        transform.localScale = new Vector3(
            _originalScale.x * factorX,
            _originalScale.y * factorY,
            _originalScale.z
        );

        // 2. Respiración de temperatura sutil y agradable a la vista
        if (_sr != null)
        {
            float heatNoise = Mathf.PerlinNoise(Time.time * colorPulseSpeed, _seed + 200f);
            // Limitamos la mezcla con colorBlendIntensity para que nunca sea agresiva
            float t = heatNoise * colorBlendIntensity;
            _sr.color = Color.Lerp(normalColor, warmGlowColor, t);
        }
    }
}