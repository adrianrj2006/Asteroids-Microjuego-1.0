using UnityEngine;

public class PlayerShooter : MonoBehaviour
{
    [Header("Referencias")]
    public GameObject gun;
    public GameObject bulletPrefab;

    [Header("Ajustes de Disparo Cargado")]
    public float maxChargeTime = 1.0f;
    public float minHoldToCharge = 0.15f;
    public float chargedScaleMultiplier = 3.2f;
    public float chargedSpeedMultiplier = 1.5f;
    public int chargedPierceCapacity = 4;

    [Header("Retroceso y Tensión")]
    public float normalRecoil = 0.08f;
    public float chargedRecoil = 1.2f;
    [Range(0.01f, 0.15f)]
    public float maxVibrationPercent = 0.065f;

    [Header("Sistema de Calor")]
    public float baseHeatCost = 0.14f;
    public float maxChargedHeatCost = 0.32f;
    public float coolDownRate = 0.35f;
    public float visualHeatThreshold = 0.35f;
    public Color warmHeatColor = new Color(1f, 0.55f, 0.1f);
    public Color maxHeatColor = Color.red;

    private float _currentHeat = 0f;
    private bool _isOverheated = false;
    private SpriteRenderer _shipRenderer;
    private Color _originalShipColor;
    private Rigidbody _rigid;
    private Collider _playerCollider;
    private Vector3 _originalScale;

    private float _chargeTimer = 0f;
    private bool _isCharging = false;

    void Start()
    {
        _shipRenderer = GetComponent<SpriteRenderer>();
        if (_shipRenderer != null)
        {
            _originalShipColor = _shipRenderer.color;
        }

        _rigid = GetComponent<Rigidbody>();
        _playerCollider = GetComponent<Collider>(); // Guardamos el collider de la nave
        _originalScale = transform.localScale;
    }

    void Update()
    {
        HandleShooting();
        HandleCooling();
        UpdateHeatVisuals();
    }

    void HandleShooting()
    {
        if (_isOverheated)
        {
            CancelCharge();
            return;
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            _isCharging = true;
            _chargeTimer = 0f;
        }

        if (Input.GetKey(KeyCode.Space) && _isCharging)
        {
            _chargeTimer += Time.deltaTime;

            if (_chargeTimer > minHoldToCharge)
            {
                float chargeRatio = Mathf.Clamp01(_chargeTimer / maxChargeTime);
                float vibration = Random.Range(-maxVibrationPercent, maxVibrationPercent) * chargeRatio;
                transform.localScale = _originalScale * (1f + vibration);
            }
        }

        if (Input.GetKeyUp(KeyCode.Space) && _isCharging)
        {
            Fire();
            CancelCharge();
        }
    }

    void Fire()
    {
        GameObject bulletObj = Instantiate(bulletPrefab, gun.transform.position, gun.transform.rotation);
        
        // 1. Evitar el bug de expulsión física con la nave
        Collider bulletCollider = bulletObj.GetComponent<Collider>();
        if (_playerCollider != null && bulletCollider != null)
        {
            Physics.IgnoreCollision(_playerCollider, bulletCollider);
        }

        Bullet balaScript = bulletObj.GetComponent<Bullet>();
        if (balaScript != null)
        {
            balaScript.targetVector = transform.right;
        }

        float chargeRatio = Mathf.Clamp01(_chargeTimer / maxChargeTime);

        if (chargeRatio >= 1.0f)
        {
            if (balaScript != null)
            {
                balaScript.SetupChargedShot(chargedScaleMultiplier, chargedSpeedMultiplier, chargedPierceCapacity);
            }

            AddHeat(maxChargedHeatCost);

            if (_rigid != null)
            {
                _rigid.AddForce(-transform.right * chargedRecoil, ForceMode.Impulse);
            }
        }
        else
        {
            float dynamicHeat = Mathf.Lerp(baseHeatCost, maxChargedHeatCost * 0.7f, chargeRatio);
            AddHeat(dynamicHeat);

            if (_rigid != null)
            {
                _rigid.AddForce(-transform.right * normalRecoil, ForceMode.Impulse);
            }
        }
    }

    void CancelCharge()
    {
        _isCharging = false;
        _chargeTimer = 0f;
        transform.localScale = _originalScale;
    }

    void AddHeat(float amount)
    {
        _currentHeat += amount;
        if (_currentHeat >= 1f)
        {
            _currentHeat = 1f;
            _isOverheated = true;
        }
    }

    void HandleCooling()
    {
        if (_currentHeat > 0)
        {
            _currentHeat -= coolDownRate * Time.deltaTime;
            if (_currentHeat < 0) _currentHeat = 0;
        }

        if (_isOverheated && _currentHeat <= 0)
        {
            _isOverheated = false;
        }
    }

    void UpdateHeatVisuals()
    {
        if (_shipRenderer == null) return;

        float factorVisual = 0f;
        if (_currentHeat > visualHeatThreshold)
        {
            factorVisual = Mathf.InverseLerp(visualHeatThreshold, 1f, _currentHeat);
        }

        Color colorObjetivo = _originalShipColor;
        if (factorVisual > 0f)
        {
            Color colorCalor = Color.Lerp(warmHeatColor, maxHeatColor, factorVisual);
            colorObjetivo = Color.Lerp(_originalShipColor, colorCalor, factorVisual);
        }

        _shipRenderer.color = Color.Lerp(_shipRenderer.color, colorObjetivo, Time.deltaTime * 6f);
    }
}