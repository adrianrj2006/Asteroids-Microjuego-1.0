using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseManager : MonoBehaviour
{
    [Header("UI")]
    [Tooltip("Panel o texto que aparece al pausar. Déjalo vacío si solo quieres atajos de teclado.")]
    public GameObject pauseMenuPanel;

    private bool _isPaused = false;

    void Start()
    {
        // Asegura que el tiempo arranque normal al entrar a la escena
        Time.timeScale = 1f;

        if (pauseMenuPanel != null)
        {
            pauseMenuPanel.SetActive(false);
        }
    }

    void Update()
    {
        // Alternar pausa con Escape o la tecla P
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
        {
            if (_isPaused)
            {
                Resume();
            }
            else
            {
                Pause();
            }
        }

        // Reinicio rápido en cualquier momento con la tecla R
        if (Input.GetKeyDown(KeyCode.R))
        {
            Restart();
        }
    }

    public void Pause()
    {
        _isPaused = true;
        Time.timeScale = 0f; // Congela físicas, movimientos y timers

        if (pauseMenuPanel != null)
        {
            pauseMenuPanel.SetActive(true);
        }
    }

    public void Resume()
    {
        _isPaused = false;
        Time.timeScale = 1f; // Reactiva el juego

        if (pauseMenuPanel != null)
        {
            pauseMenuPanel.SetActive(false);
        }
    }

    public void Restart()
    {
        Time.timeScale = 1f; // Imprescindible descongelar antes de recargar
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}