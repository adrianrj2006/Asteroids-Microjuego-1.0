using UnityEngine;

public class MeteorSpawner : MonoBehaviour
{
    public GameObject asteroidPrefab;

    [Header("Ajustes de Generación")]
    public float spawnRatePerMinute = 30f;
    public float spawnRateIncrement = 1f;
    private float spawnNext = 0;

    [Header("Límites de Generación")]
    public float xCoordsLimit = 7f;
    public float yCoordsLimit = 8f;
    public float maxTimeLife = 5f;

    [Header("Control de Caída")]
    public float minSpeed = 2f;                   // Velocidad mínima
    public float maxSpeed = 4.5f;                 // Velocidad máxima
    [Range(0f, 45f)]
    public float maxAngleVariation = 25f;         // Inclinación máxima en grados

    void Update()
    {
        if (Time.time > spawnNext)
        {
            spawnNext = Time.time + (60f / spawnRatePerMinute);
            spawnRatePerMinute += spawnRateIncrement;

            // Posición aleatoria en la parte superior
            float randX = Random.Range(-xCoordsLimit, xCoordsLimit);
            Vector3 spawnPosition = new Vector3(randX, yCoordsLimit, 0f);

            // Dirección inclinada (hacia abajo con variación a los lados)
            float randomAngle = Random.Range(-maxAngleVariation, maxAngleVariation);
            Vector3 trajectory = Quaternion.Euler(0, 0, randomAngle) * Vector3.down;

            // Orientar el meteorito para que el fuego apunte hacia atrás
            // Como el fuego en la imagen está arriba, orientamos 'up' en sentido contrario a la caída
            Quaternion rotation = Quaternion.FromToRotation(Vector3.up, -trajectory);

            // Instanciar y asignar velocidad
            GameObject meteor = Instantiate(asteroidPrefab, spawnPosition, rotation);
            
            Rigidbody rb = meteor.GetComponent<Rigidbody>();
            if (rb != null)
            {
                float randomSpeed = Random.Range(minSpeed, maxSpeed);
                rb.linearVelocity = trajectory * randomSpeed;
            }

            Destroy(meteor, maxTimeLife);
        }
    }
}