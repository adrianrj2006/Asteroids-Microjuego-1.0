using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class MenuManager : MonoBehaviour
{
    [Header("Referencias UI")]
    public TextMeshProUGUI pressStartText;
    public TextMeshProUGUI highScoreText;
    public TextMeshProUGUI lastScoreText;

    [Header("Escena a Cargar")]
    public string gameSceneName = "SampleScene";

    [Header("Efecto Arcade")]
    public float blinkSpeed = 2f; // Velocidad de parpadeo del texto de inicio

    void Start()
    {
        Time.timeScale = 1f;

        // 1. Cargar Récord
        int highScore = PlayerPrefs.GetInt("HighScore", 0);
        if (highScoreText != null)
        {
            highScoreText.text = "HIGH SCORE: " + highScore.ToString("D6");
        }

        // 2. Cargar Última Puntuación (si venimos de morir)
        if (PlayerPrefs.HasKey("LastScore"))
        {
            int lastScore = PlayerPrefs.GetInt("LastScore");
            if (lastScoreText != null)
            {
                lastScoreText.gameObject.SetActive(true);
                lastScoreText.text = "LAST SCORE: " + lastScore.ToString("D6");
            }
        }
        else if (lastScoreText != null)
        {
            lastScoreText.gameObject.SetActive(false); // Ocultar en el primer inicio
        }
    }

    void Update()
    {
        // Parpadeo retro del texto "PRESS SPACE"
        if (pressStartText != null)
        {
            pressStartText.enabled = (Mathf.FloorToInt(Time.time * blinkSpeed) % 2 == 0);
        }

        // Iniciar partida
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return))
        {
            SceneManager.LoadScene(gameSceneName);
        }
    }
}